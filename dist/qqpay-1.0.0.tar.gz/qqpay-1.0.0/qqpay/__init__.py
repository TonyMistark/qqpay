#!/usr/bin/env python
# coding: utf-8
import time
from datetime import datetime, timedelta
from .base import Base
from .utils import timezone, get_external_ip

__version__ = "1.0.0"

class Qpay(Base):

    def unified_order_apply(self, out_trade_no, total_fee, body, client_ip=None, attach=None, trade_type="APP", limit_pay=None,
                           fee_type='CNY', time_start=None, time_expire=None, **kwargs):
        now = datetime.fromtimestamp(time.time(), tz=timezone('Asia/Shanghai'))
        hours_later = now + timedelta(hours=2)
        if time_start is None:
            time_start = now
        if time_expire is None:
            time_expire = hours_later
        data = {
            "out_trade_no": out_trade_no,
            "body": body,
            "attach": attach,
            "total_fee": total_fee,
            "trade_type": trade_type,
            "fee_type": fee_type,
            "time_start": time_start.strftime('%Y%m%d%H%M%S'),
            "time_expire": time_expire.strftime('%Y%m%d%H%M%S'),
            "spbill_create_ip": client_ip or get_external_ip()
        }
        if limit_pay:
            data["limit_pay"] = limit_pay
        data.update(kwargs)
        return self.post(url="cgi-bin/pay/qpay_unified_order.cgi", data=data)

    def query(self, **kwargs):
        data = {}
        data.update(kwargs)
        return self.post(url="cgi-bin/pay/qpay_order_query.cgi", data=data)
